import tkinter as tk
from tkinter import messagebox

def noALE():
    messagebox.showinfo("Mensagem", "Hello ALE!")

janela = tk.Tk()
janela.title("ALE")
janela.geometry("300x300")

label = tk.Label(janela, text = "Introdução ALE")
label.pack(pady = 10)

botao = tk.Button(janela, text = "Clique no ALE", command = noALE)
botao.pack(pady = 10)

janela.mainloop()