import tkinter as tk

def noAle1():
    num1 = int(txt1.get())
    num2 = int(txt2.get())
    soma = num1 + num2
    somaD = str(soma)
    resultado.config(text = "Resultado: " + somaD)

def noAle2():
    num1 = int(txt1.get())
    num2 = int(txt2.get())
    menos = num1 - num2
    menosD = str(menos)
    resultado.config(text = "Resultado: " + menosD)

def noAle3():
    num1 = int(txt1.get())
    num2 = int(txt2.get())
    vezes = num1 * num2
    vezesD = str(vezes)
    resultado.config(text = "Resultado: " + vezesD)

def noAle4():
    num1 = int(txt1.get())
    num2 = int(txt2.get())
    dividi = num1 / num2
    dividiD = str(dividi)
    resultado.config(text = "Resultado: " + dividiD)


janela = tk.Tk()
janela.title("ALEE")
janela.geometry("250x250")


txt1 = tk.Entry(janela)
txt1.grid(row = 2, column = 1, columnspan = 1)
txt2 = tk.Entry(janela)
txt2.grid(row = 2, column = 2, columnspan = 1)


btn = tk.Button(janela, text = "+", command = noAle1, width = 4, height = 2)
btn.grid(row = 3, column = 1, columnspan = 1)
btn2 = tk.Button(janela, text = "-", command = noAle2, width = 4, height = 2)
btn2.grid(row = 3, column = 2, columnspan = 2)
btn3 = tk.Button(janela, text = "*", command = noAle3, width = 4, height = 2)
btn3.grid(row = 4, column = 1, columnspan = 1)
btn4 = tk.Button(janela, text = "/", command = noAle4, width = 4, height = 2)
btn4.grid(row = 4, column = 2, columnspan = 2)

resultado = tk.Label(janela, text = "Resultado: ")
resultado.grid(row = 5, column = 1, columnspan = 20)

janela.mainloop()