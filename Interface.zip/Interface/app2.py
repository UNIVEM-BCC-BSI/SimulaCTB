import tkinter as tk

def noAle():
    nome = txtnome.get()
    mensagem = "Ale " + nome
    lblnome.config(text = mensagem)

janela = tk.Tk()
janela.title("ALEE")
janela.geometry("300x300")

lblIntroducao = tk.Label(janela, text = "Digite seu nome")
lblIntroducao.grid(row = 1, column = 1, columnspan = 2)

txtnome = tk.Entry(janela)
txtnome.grid(row = 2, column = 1, columnspan = 2)

btn = tk.Button(janela, text = "Clique", command = noAle)
btn.grid(row = 3, column = 1, columnspan = 2)

mensagem = ""
lblnome = tk.Label(janela, text = "Ale")
lblnome.grid(row = 4, column = 1, columnspan = 2)

janela.mainloop()